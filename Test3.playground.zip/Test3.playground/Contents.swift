import UIKit
//: ### Please enter your full name below.
print("Test Results: Narek Ayvazyan")
//: ---
//: Example url https://itunes.apple.com/us/app/keynote/id409183694?mt=12
//:
//: ---
//: ### Question 1
//: Which of following options is the protocol in the URL bellow?
//: 1. https://
//: 2. itunes.
//: 3. apple.com
//: 4. /us/app/keynote/id409183694
//: 5. ?mt=12
print("Question 1: 1")
//: ---
//: ### Question 2
//: Which of following options is the query parameter in the URL bellow?
//: 1. https://
//: 2. itunes.
//: 3. apple.com
//: 4. /us/app/keynote/id409183694
//: 5. ?mt=12
print("Question 2: 5")
//: ---
//: ### Question 3
//: Which of following options is the path in the URL bellow?
//: 1. https://
//: 2. itunes.
//: 3. apple.com
//: 4. /us/app/keynote/id409183694
//: 5. ?mt=12
print("Question 3: 4")
//: ---
//: ### Question 4
//: When URLSessionDataTask request is finished, the URLSession will execute the code you run in completion handler. What parameters are made available to you in the closure?
//: 1. Data
//: 2. Data?
//: 3. Error
//: 4. Error?
//: 5. URLResponse
//: 6. URLResponse?
print("Question 4: 2")
//: ---
//: ### Question 5
//: Most modern APIs return data in the following format:
//: 1. XML
//: 2. JSON
//: 3. HTML
//: 4. HTTP
print("Question 5: 2 ")
//: ---
//: ### Question 6
//: Which Swift type annotations best describes the JSON format?
//: 1. [String: String]
//: 2. [String: Any]
//: 3. [[String: Any]]
//: 4. [Any: Any]
print("Question 6: 1 ? ")
//: ---
//: ### Question 7
//: Which objects is able to decode JSON data into native Swift types?
//: 1. PropertyListDecoder
//: 2. JSONDecoder
//: 3. JSONEncoder
//: 4. JSONSerialization
print("Question 7: 2 ")
//: ---
//: ### Question 8
//: Which of the following explains what types are decodable by a Decoder object?
//: 1. Only objects that conform to the Codable protocol
//: 2. All objects in Swift
//: 3. Only object that conform to the Encodable protocol
//: 4. All object that conforms to the Decodable protocol
print("Question 8: 4")
//: ---
//: ### Question 9
//: Which queue is responsible for updating the user interface of an iOS app?
//: 1. The first, or main queue
//: 2. A background queue
print("Question 9: 1 ")
//: ---
//: ### Question 10
//: What will happen if you try to refresh the user interface in the completion handler of a network request without dispatching to the main queue?
//: 1. The interface will update immediately as expected
//: 2. The interface may update eventualy, but the timing and behavior is undefined
print("Question 10: 2 ")
//: ---
//: ### Question 11
//: What is the tool on Apple platforms for managing simultaneous work on multiple cores called?
//: 1. Dipatch Queue
//: 2. Grand Central Dispatch
//: 3. Core Data
//: 4. UIKit
print("Question 11: 2 ")
//: ---
//: ### Question 12
//: Multiple object from different threads(queues) try to access(get/set) same resource(object). This is:
//: 1. deadlock condition
//: 2. thread race condition
print("Question 12: 2")
//: ---
//: ### Question 13
//: Arrange Quality of Services in ascending order
//: 1. Default
//: 2. Utility
//: 3. User-initiated
//: 4. Background
//: 5. User-interactive
print("Question 13: 1, 5, 3, 2, 4")
//: ---
//: ### Question 14
//: In your code how can you know in which thread you are?
//: 1. DispatchQueue.currentThread
//: 2. Thread.isMainThread
//: 3. DispatchThread.current
//: 4. Thread.current
print("Question 14: 2 ")
//: ---
//: ### Question 15
//: What kind of DispatchQueues execute one task at a time in the order in which they are added to the queue?
//: 1. Concurrent
//: 2. Serial
print("Question 15: 2 ")
//: ---
//: ### Question 16
//: Concurrent Dispatch queue starts next task only after previos one is finished.
//: 1. True
//: 2. False
//: 3. Can work this way using some tools or attributes
print("Question 16: 3 ")
//: ---
//: ### Question 17
//: NSLock lock code only when it calls from the same thread.
//: 1. True
//: 2. False
print("Question 17: 2 ")
//: ---
//: ### Question 18
//: DispatchQueue async execution barier attribute work same way as NSLock.
//: 1. True
//: 2. False
print("Question 18: 2  ")
//: ---
//: ### Question 19
//: ````
//: let lock1 = NSLock()
//: let lock2 = NSLock()
//:
//: func a() {
//:     lock1.lock()
//:     Thread.sleep(forTimeInterval: 1)
//:     d()
//:     lock1.unlock()
//: }
//:
//: func b() {
//:     lock1.lock()
//:     Thread.sleep(forTimeInterval: 1)
//:     lock1.unlock()
//: }
//:
//: func c() {
//:     lock2.lock()
//:     Thread.sleep(forTimeInterval: 1)
//:     b()
//:     lock2.unlock()
//: }
//:
//: func d() {
//:     lock2.lock()
//:     Thread.sleep(forTimeInterval: 1)
//:     lock2.unlock()
//: }
//: ````
//: What can be face while executing this code?
//: 1. Thread race condition
//: 2. Priority inversion condition
//: 3. Deadlock condition
//: 4. Nothing wrong with this code snipet
print("Question 19: 4")
//: ---
//: ### Question 20
//: Which main object types in Swift you know, please describe every one of it in a couple words.
"class - defines new type of object, stores properties to keep some value for later use"
"enum -  object for group of related values"
"protocol - its a list of properties, methods, protocols provides just a property not implementation"

//: ---
//: ### Question 21
//: What is the difference between  `function` and `method`. Please describe in your own words.
"methodes are part of particular type while functions are independet piece of code."

//: ---
//: ### Question 22
//: Please describe `overload` concept.
"its a concept of createing more than one function that have same name but different arguments"

//: ---
//: ### Question 23
//: Please describe `override` concept.
"override is a process that allows subclass change properties of main class "

//: ---
//: ### Question 24
//: Please describe the meaning of `Class` in OOP and Swift.


//: ---
//: ### Question 25
//: Give an example of code where the Thread race condition can be faced.


//: ---
//: ### Question 26
//: Get songs from this url https://itunes.apple.com/search?media=music&entity=song&term=Linkin , there would be artworkURL in any object. Get those artworks in 250x250 size and present it in the collectionview.


//: ---
//: ### Question 27
//: Create UIViewController with a simple button on it. When tapping on that button background color changes to randomly generated color, which you must save in a persistent store, so users never saw same color twice.

